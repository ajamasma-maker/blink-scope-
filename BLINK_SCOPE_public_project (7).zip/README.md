# BLINK//SCOPE

An educational prototype for the NASA Space Apps Challenge prompt "Planet X and SPHEREx".

## Run locally
Open `index.html` in a modern web browser. No installation or server is required.

## Publish with GitHub Pages
1. Create a public GitHub repository.
2. Upload `index.html` to the repository root.
3. Open Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select `main` and `/ (root)`, then Save.
6. Wait for the Pages URL to appear. Open it in a private/incognito window to verify public access.

## Scientific transparency
This is a front-end concept prototype. The star field and candidate position change are procedurally generated illustrative data, not actual SPHEREx observations or verified detections. It does not yet retrieve, calibrate, align, or analyze SPHEREx data.

SPHEREx's 102 spectral bands represent wavelength channels, not observation dates. A real data implementation would need to select comparable observations of the same sky region, handle calibration and image artifacts, and cross-match candidate sources with catalogs.

## Data resource
NASA/IPAC Infrared Science Archive: https://irsa.ipac.caltech.edu/Missions/spherex.html
